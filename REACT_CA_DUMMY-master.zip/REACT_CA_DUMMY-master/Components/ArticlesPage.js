import { Link } from "react-router-dom"

export const Articles = ({articles})=>{
    return(
        <div id="MainContent">
            {articles.map(article =>(
                <Link to={`/articles/${article.name}`}  id="titleandcont" key={article.name}>
                    <h3  id="title">{article.title}</h3>
                    <p  id="content">{article.content[0].substring(0, 200)}...</p>
                </Link>
            ))}
        </div>
    );
}

const CommentsList = ({comments})=>{
    return(<>
        <h3 id="CommentHeading">Comments:</h3>
        {comments.map((comment,i) =>(
            <div id="UpdateComments" key={i}>
                <h5>{comment.PostedBy}</h5>
                <p>{comment.text}</p>
            </div>
        ))}
    </>);
}
export default CommentsList;
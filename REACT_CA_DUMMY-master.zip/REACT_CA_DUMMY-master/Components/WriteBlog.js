
const WriteBlog = ()=>{
    return(
        <h1> Will be updated soon.....</h1>
    )
}

export default WriteBlog;
import { Link } from "react-router-dom";

const NavBar = ()=>{
    return(
        <div>
            <nav id="navbar">
                <ul id="ulist">
                    <li id="items1">
                        <span><Link to="/"><b>Home</b></Link></span>
                    </li>
                    <li id="items2">
                        <span><Link to="/about"><b>About</b></Link></span>
                    </li>
                    <li id="items3">
                        <span><Link to="/articles"><b>Articles</b></Link></span>
                    </li>
                </ul>
            </nav>
        </div>
    );
}
export default NavBar;
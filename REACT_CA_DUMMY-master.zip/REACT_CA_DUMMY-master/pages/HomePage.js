

const HomePage = ()=>{
    return(
        <>
            <h1>Hello, welcome to my WriteBlog!</h1>
            <p id="NormalContent">

            You can Read the blogs of your own interest. Whether you're a experienced profssional or a student, we have something for you.

            Explore our articles to see how we can help you. Our team of experienced experts is always working to improve our offerings and provide you with the best experience possible.

            We're committed to providing you with the best [products/services/features] and customer service possible. If you have any questions or concerns, please don't hesitate to contact us.

            Thank you for choosing WriteBlogs!
            </p>
            <p id="NormalContent">
                Donec vel mauris lectus. Etiam nec lectus urna. Sed sodales ultrices dapibus. 
                Nam blandit tristique risus, eget accumsan nisl interdum eu. Aenean ac accumsan 
                nisi. Nunc vel pulvinar diam. Nam eleifend egestas viverra. Donec finibus lectus 
                sed lorem ultricies, eget ornare leo luctus. Morbi vehicula, nulla eu tempor 
                interdum, nibh elit congue tellus, ac vulputate urna lorem nec nisi. Morbi id 
                consequat quam. Vivamus accumsan dui in facilisis aliquet.,
            </p>
            <p id="NormalContent">
                Etiam nec lectus urna. Sed sodales ultrices dapibus. 
                Nam blandit tristique risus, eget accumsan nisl interdum eu. Aenean ac accumsan 
                nisi. Nunc vel pulvinar diam. Nam eleifend egestas viverra. Donec finibus lectus 
                sed lorem ultricies, eget ornare leo luctus. Morbi vehicula, nulla eu tempor 
                interdum, nibh elit congue tellus, ac vulputate urna lorem nec nisi. Morbi id 
                consequat quam. Vivamus accumsan dui in facilisis aliquet.,
            </p>
        </>
    );
}

export default HomePage;

import articles from "./article-content";
import { Articles } from "../Components/ArticlesPage";

const ArticlesListPage = ()=>{
    return(
        <div id="MainContent">
            <h1>Articles</h1>
            <Articles articles={articles} />
        </div>    
    );
}

export default ArticlesListPage;
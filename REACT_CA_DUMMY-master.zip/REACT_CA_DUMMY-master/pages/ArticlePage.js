import articles  from "./article-content"
import { useParams } from "react-router-dom";
import NotFoundPage from "./PageNotFound";
import { useEffect, useState } from "react";
import axios from 'axios';
import CommentsList from "../Components/CommentsList";
import AddCommentForm from "../Components/AddCommentForm";

const ArticlePage = ()=>{
    const [articleInfo, setArticleInfo] = useState({upvotes: 0, comments:[]});
    const { articleId } = useParams();

    useEffect(()=>{
        const loadArticleInfo =async ()=>{
            const response = await axios.get(`/api/articles/${articleId}`);
            const newArticle = response.data;
            setArticleInfo(newArticle);
        }
        loadArticleInfo();
    },[articleId]);

    const article = articles.find(article => article.name === articleId)

    const addUpvote = async ()=>{
        const response = await axios.put(`/api/articles/${articleId}/upvotes`);
        const updatedArticle = response.data;
        setArticleInfo(updatedArticle);
    }

    if(!article){
        return( <NotFoundPage /> );
    }
    return(
        <>
            <h1>{article.title}</h1>
            <div id="addUpvote">
                <button onClick={addUpvote}>Upvote</button>
                <p id="para">This article has {articleInfo.upvotes} upvote(s)</p>
            </div>
            {article.content.map((paragraph, i) => (
                <p key={i} id="para">{paragraph}</p>
            ))}
            <AddCommentForm 
                articleName={articleId}
                onArticleUpdated={updatedArticle => setArticleInfo(updatedArticle)}
            />

            <CommentsList comments={articleInfo.comments} />
        </>
    );
}

export default ArticlePage;
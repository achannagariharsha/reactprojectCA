import path from 'path';
import express from 'express';
import 'dotenv/config';
import { db, connectToDb }  from './db.js'
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "../build")));

app.get(/^(?!\/api).+/, (req, res) => {
    res.sendFile(path.join(__dirname, '../build/index.html'));
})

app.get("/api/articles/:name",async (req,res) => {
    const { name } = req.params;
    
    const article = await db.collection("articles").findOne({name});
    if(article)
    {
        res.json(article);
    }
    else{
        res.sendStatus(404);
    }
});


app.put('/api/articles/:name/upvotes', async function(req,res){
    
    const { name } = req.params;

    await db.collection("articles").updateOne({"name": name }, {
        $inc:{ upvotes: 1}
    });


    const article = await db.collection("articles").findOne({ "name":name })
    if(article){
        res.json(article);
    }
    else{
        res.send('That article doesn\'t exist');
    }
});

app.post("/api/articles/:name/comments",async function(req,res){
    const { name } = req.params;
    const { PostedBy, text } = req.body;

    await db.collection("articles").updateOne({name},{
        $push:{ comments:{PostedBy, text} }
    });

    const article = await db.collection("articles").findOne({ name });

    if(article){
        res.json(article);
    }
    else{
        res.send("That article doesn't exist");
    }
});

const PORT = process.env.PORT || 8000 ;

connectToDb(()=>{
    console.log("Successfully connect to database And listening to: "+ PORT);
    app.listen(PORT,()=>{
        console.log("Successfully data extracted...");
    });
})



